#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() {
    const int SUBJECTS = 5;
    const double PASS_MARKS = 35.0;

    string subjectNames[SUBJECTS] = {
        "Mathematics", "Physics", "Chemistry", "English", "Computer Science"
    };
    double marks[SUBJECTS];
    double total = 0.0;

    cout << "====================================\n";
    cout << "       STUDENT MARKS CALCULATOR\n";
    cout << "====================================\n";
    cout << "Enter marks out of 100 for each subject.\n\n";

    for (int i = 0; i < SUBJECTS; i++) {
        while (true) {
            cout << subjectNames[i] << ": ";
            if (cin >> marks[i] && marks[i] >= 0 && marks[i] <= 100) {
                break;
            }

            cout << "Please enter a valid mark from 0 to 100.\n";
            cin.clear();
            cin.ignore(10000, '\n');
        }

        total += marks[i];
    }

    double percentage = total / SUBJECTS;
    bool passed = true;

    for (int i = 0; i < SUBJECTS; i++) {
        if (marks[i] < PASS_MARKS) {
            passed = false;
        }
    }

    cout << "\n--------------- RESULT -------------\n";
    cout << fixed << setprecision(2);
    cout << "Total Marks : " << total << " / " << SUBJECTS * 100 << '\n';
    cout << "Percentage  : " << percentage << "%\n";
    cout << "Result      : " << (passed ? "PASS" : "FAIL") << '\n';
    cout << "------------------------------------\n";

    if (percentage >= 90) {
        cout << "Performance : Excellent\n";
    } else if (percentage >= 75) {
        cout << "Performance : Very Good\n";
    } else if (percentage >= 60) {
        cout << "Performance : Good\n";
    } else if (percentage >= 35 && passed) {
        cout << "Performance : Keep improving\n";
    } else {
        cout << "Performance : More practice needed\n";
    }

    return 0;
}
