# Student Marks Calculator (C++)

A beginner-friendly C++ console project that calculates a student's total marks, percentage, pass/fail result, and a simple performance label across five subjects.

## Features

- Takes marks for five subjects.
- Checks that each mark is between 0 and 100.
- Calculates total marks and percentage.
- Shows **PASS** only if every subject has at least 35 marks.
- Displays a performance label based on the result.

## Subjects

- Mathematics
- Physics
- Chemistry
- English
- Computer Science

## Requirements

A C++ compiler, such as `g++`.

## How to run

### Windows (with MinGW g++ installed)

Open Command Prompt or the VS Code terminal in this folder and run:

```bash
g++ main.cpp -o marks_calculator
marks_calculator.exe
```

### macOS / Linux

```bash
g++ main.cpp -o marks_calculator
./marks_calculator
```

## Example

```text
====================================
       STUDENT MARKS CALCULATOR
====================================
Enter marks out of 100 for each subject.

Mathematics: 85
Physics: 78
Chemistry: 81
English: 90
Computer Science: 95

--------------- RESULT -------------
Total Marks : 429.00 / 500
Percentage  : 85.80%
Result      : PASS
------------------------------------
Performance : Very Good
```

## Concepts used

- Variables and arrays
- `for` loops
- Input validation
- Conditional statements
- Basic arithmetic
- Console input/output

## Future improvements

- Ask for the student's name.
- Support a custom number of subjects.
- Save results to a file.
- Add letter grades.

## License

This project is available for learning and personal use.
